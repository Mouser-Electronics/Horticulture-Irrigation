#ifndef CRYPTOAUTHLIB_MAIN_H
#define CRYPTOAUTHLIB_MAIN_H

/**
 * \brief Initialize Cryptoauthlib Stack
 */
void cryptoauthlib_init(void);


#endif /* CRYPTOAUTHLIB_MAIN_H */