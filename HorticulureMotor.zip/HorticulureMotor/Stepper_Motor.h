/* 
 * File:   Stepper_Motor.h
 * Author: joseph.downing
 *
 * Created on December 3, 2019, 9:12 AM
 */

#ifndef STEPPER_MOTOR_H
#define	STEPPER_MOTOR_H


#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef	__cplusplus
extern "C" {
#endif

void StepWrite(uint8_t address, uint8_t data);
void StepRead(uint8_t address);
void Stepper_Init (void);



#ifdef	__cplusplus
}
#endif

#endif	/* STEPPER_MOTOR_H */

