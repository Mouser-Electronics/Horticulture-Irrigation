
#include "Stepper_Motor.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

#define CS LATAbits.LATA0       // sets Chip Select value, Active Low

#define _XTAL_FREQ_32000000
#define FOSC (16000000)
#define FCY (FOSC/2)

#include "libpic30.h"


#define MCP_IODIR	0x00		/* init/reset:  all ones */
#define MCP_IPOL	0x01
#define MCP_GPINTEN	0x02
#define MCP_DEFVAL	0x03
#define MCP_INTCON	0x04
#define MCP_IOCON	0x05
#define MCP_GPPU	0x06
#define MCP_INTF	0x07
#define MCP_INTCAP	0x08
#define MCP_GPIO	0x09
#define MCP_OLAT	0x0a

uint8_t readData;
int j;


void StepWrite(uint8_t address, uint8_t writeData)
{
    CS = 0;
    SPI2_Exchange8bit(0x40);        // Send Device Opcode R/W 0
    SPI2_Exchange8bit(address);     //Send Register Address
    SPI2_Exchange8bit(writeData);   //Data 
    CS = 1;
    __delay_us(1000);
    return;
}

void StepRead(uint8_t address)
{
    CS = 0;
    SPI2_Exchange8bit(0x41);            // Send Device Opcode R/W 1
    SPI2_Exchange8bit(address);         //Send Register Address
    readData = SPI2_Exchange8bit(0x0);  //Read Address
    CS = 1;
    __delay_ms(1);
    return(readData);
}

void StepperCCW()
{
    j = 0;
    while ( j < 50 )
    {
        StepWrite(MCP_GPIO, 0x80);
        StepWrite(MCP_GPIO, 0x3C);
        StepWrite(MCP_GPIO, 0x00);
        StepWrite(MCP_GPIO, 0x3C);
        StepWrite(MCP_GPIO, 0x40);
        StepWrite(MCP_GPIO, 0x3C);
        StepWrite(MCP_GPIO, 0xC0);
        StepWrite(MCP_GPIO, 0x3C);
        j++;
    }
    StepWrite(MCP_GPIO, 0x80);
    StepWrite(MCP_GPIO, 0x3C);
}

void StepperCW()
{
    j = 0;
    while ( j < 50 )
    {
        StepWrite(MCP_GPIO, 0xC0);
        StepWrite(MCP_GPIO, 0x3C);
        StepWrite(MCP_GPIO, 0x40);
        StepWrite(MCP_GPIO, 0x3C);
        StepWrite(MCP_GPIO, 0x00);
        StepWrite(MCP_GPIO, 0x3C);
        StepWrite(MCP_GPIO, 0x80);
        StepWrite(MCP_GPIO, 0x3C);
        j++;
    }
    StepWrite(MCP_GPIO, 0xC0);
    StepWrite(MCP_GPIO, 0x3C);
}


void Stepper_Init (void)
{    
    CS = 0;     
    SPI2_Exchange8bit(0x40);        // Send Device Opcode R/W 0
    SPI2_Exchange8bit(MCP_IODIR);   //Send Register Address
    SPI2_Exchange8bit(0x00);        // IODIR Register - all GPIO set to output
    CS = 1;
    CS = 0;     
    SPI2_Exchange8bit(0x40);        // Send Device Opcode R/W 0
    SPI2_Exchange8bit(MCP_GPINTEN); //Send Register Address
    SPI2_Exchange8bit(0x00);        //Disable interrupts
    __delay_ms(5);
    return;
}
